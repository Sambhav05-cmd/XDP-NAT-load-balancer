package main

import (
	"encoding/binary"
	"net"
)

func parseIPv4Must(s string) uint32 {
	ip := net.ParseIP(s).To4()
	return binary.LittleEndian.Uint32(ip)
}

// updateBackend updates the weight of a backend identified by ip:port.
// Walks selection_array to get stable IDs, looks each up in the backends
// hash map — never uses array positions directly.
func updateBackend(objs any, ip string, port uint16, weight uint16) {
	keyIP := parseIPv4Must(ip)

	switch o := objs.(type) {

	case *lb3Objects:
		var count uint32
		o.lb3Maps.BackendCount.Lookup(uint32(0), &count)
		for i := uint32(0); i < count; i++ {
			var id uint32
			if err := o.lb3Maps.SelectionArray.Lookup(i, &id); err != nil {
				continue
			}
			var b lb3Backend
			if err := o.lb3Maps.Backends.Lookup(&id, &b); err != nil {
				continue
			}
			if b.Ip == keyIP && b.Port == htons(port) {
				b.Weight = weight
				o.lb3Maps.Backends.Update(&id, &b, 0)
				return
			}
		}

	case *lb4Objects:
		var count uint32
		o.lb4Maps.BackendCount.Lookup(uint32(0), &count)
		for i := uint32(0); i < count; i++ {
			var id uint32
			if err := o.lb4Maps.SelectionArray.Lookup(i, &id); err != nil {
				continue
			}
			var b lb4Backend
			if err := o.lb4Maps.Backends.Lookup(&id, &b); err != nil {
				continue
			}
			if b.Ip == keyIP && b.Port == htons(port) {
				b.Weight = weight
				o.lb4Maps.Backends.Update(&id, &b, 0)
				return
			}
		}
	}
}

func htons(p uint16) uint16 {
	return (p<<8)&0xff00 | p>>8
}