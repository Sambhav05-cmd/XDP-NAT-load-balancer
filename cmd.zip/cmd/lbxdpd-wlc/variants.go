package main

import (
	"encoding/binary"
	"encoding/json"
	"fmt"
	"net"
	"os"

	"github.com/cilium/ebpf"
)

// ── config types ──────────────────────────────────────────────────────────────

type backendCfg struct {
	IP     string `json:"ip"`
	Port   uint16 `json:"port"`
	Weight uint16 `json:"weight"`
}

type serviceCfg struct {
	VIP  string `json:"vip"`
	Port uint16 `json:"port"`
}

type config struct {
	Service  serviceCfg   `json:"service"`
	Backends []backendCfg `json:"backends"`
}

// ── shared helpers ────────────────────────────────────────────────────────────

// NOTE: htons is declared in backend.go — do not redeclare it here.

func parseIPv4Cfg(s string) (uint32, error) {
	ip := net.ParseIP(s).To4()
	if ip == nil {
		return 0, fmt.Errorf("invalid IPv4: %q", s)
	}
	return binary.LittleEndian.Uint32(ip), nil
}

const (
	pinDir       = "/sys/fs/bpf/lbxdp"
	sentinelPath = "/run/lbxdp.mode"
)

// nextBackendID is the process-wide stable ID counter.
// Starts at 1 — 0 is reserved as invalid/sentinel in BPF.
var nextBackendID uint32 = 1

func pinMaps(pins map[string]*ebpf.Map, modeName string) error {
	if err := os.MkdirAll(pinDir, 0755); err != nil {
		return fmt.Errorf("mkdir %s: %w", pinDir, err)
	}
	for path, m := range pins {
		if err := m.Pin(path); err != nil {
			return fmt.Errorf("pin %s: %w", path, err)
		}
	}
	return os.WriteFile(sentinelPath, []byte(modeName), 0644)
}

func loadConfig(cfgPath string) (config, error) {
	var cfg config
	data, err := os.ReadFile(cfgPath)
	if err != nil {
		return cfg, fmt.Errorf("read config %q: %w", cfgPath, err)
	}
	if err := json.Unmarshal(data, &cfg); err != nil {
		return cfg, fmt.Errorf("parse config %q: %w", cfgPath, err)
	}
	return cfg, nil
}

func defaultWeight(w uint16) uint16 {
	if w == 0 {
		return 1
	}
	return w
}

// ── EST variant (lb3 / lb_wlc_est.c) ─────────────────────────────────────────

type wlcEstVariant struct {
	objs lb3Objects
}

func newWlcEstVariant() (*wlcEstVariant, error) {
	v := &wlcEstVariant{}
	if err := loadLb3Objects(&v.objs, nil); err != nil {
		return nil, fmt.Errorf("load BPF objects (wlc-est): %w", err)
	}
	if err := pinMaps(map[string]*ebpf.Map{
		pinDir + "/backends":        v.objs.lb3Maps.Backends,
		pinDir + "/backend_count":   v.objs.lb3Maps.BackendCount,
		pinDir + "/services":        v.objs.lb3Maps.Services,
		pinDir + "/selection_array": v.objs.lb3Maps.SelectionArray,
	}, "wlc"); err != nil {
		v.objs.Close()
		return nil, err
	}
	return v, nil
}

func (v *wlcEstVariant) Program() *ebpf.Program { return v.objs.XdpLoadBalancer }
func (v *wlcEstVariant) Close()                 { v.objs.Close() }

func (v *wlcEstVariant) Init(cfgPath string) error {
	if err := initPorts(func(p uint16) error {
		return v.objs.lb3Maps.FreePorts.Update(nil, &p, ebpf.UpdateAny)
	}); err != nil {
		return fmt.Errorf("init ports: %w", err)
	}

	cfg, err := loadConfig(cfgPath)
	if err != nil {
		return err
	}

	if err := v.AddService(cfg.Service.VIP, cfg.Service.Port); err != nil {
		return fmt.Errorf("add service: %w", err)
	}

	for i, b := range cfg.Backends {
		ip, err := parseIPv4Cfg(b.IP)
		if err != nil {
			return fmt.Errorf("backend[%d] IP: %w", i, err)
		}
		id := nextBackendID
		nextBackendID++
		be := lb3Backend{
			Ip:     ip,
			Port:   htons(b.Port),
			Conns:  0,
			Weight: defaultWeight(b.Weight),
		}
		if err := v.objs.lb3Maps.Backends.Update(&id, &be, ebpf.UpdateAny); err != nil {
			return fmt.Errorf("update backends id=%d: %w", id, err)
		}
		pos := uint32(i)
		if err := v.objs.lb3Maps.SelectionArray.Update(pos, &id, ebpf.UpdateAny); err != nil {
			return fmt.Errorf("update selection_array[%d]: %w", i, err)
		}
	}

	cnt := uint32(len(cfg.Backends))
	if err := v.objs.lb3Maps.BackendCount.Update(uint32(0), &cnt, ebpf.UpdateAny); err != nil {
		return fmt.Errorf("update backend_count: %w", err)
	}
	return nil
}

func (v *wlcEstVariant) UpdateWeight(ip string, port, weight uint16) error {
	return wlcUpdateWeight(v.objs.lb3Maps.Backends, v.objs.lb3Maps.BackendCount,
		v.objs.lb3Maps.SelectionArray, ip, port, weight)
}

func (v *wlcEstVariant) AddBackend(ip string, port, weight uint16) error {
	return wlcAddBackend(v.objs.lb3Maps.Backends, v.objs.lb3Maps.BackendCount,
		v.objs.lb3Maps.SelectionArray, ip, port, weight,
		func(ip uint32, port, weight uint16) interface{} {
			return &lb3Backend{Ip: ip, Port: port, Conns: 0, Weight: weight}
		})
}

func (v *wlcEstVariant) DeleteBackend(ip string, port uint16) error {
	return wlcDeleteBackend(v.objs.lb3Maps.Backends, v.objs.lb3Maps.BackendCount,
		v.objs.lb3Maps.SelectionArray, ip, port,
		func(m *ebpf.Map, id uint32) (uint32, uint16, error) {
			var b lb3Backend
			if err := m.Lookup(&id, &b); err != nil {
				return 0, 0, err
			}
			return b.Ip, b.Port, nil
		},
		func(m *ebpf.Map, id uint32) (uint32, error) {
			var b lb3Backend
			if err := m.Lookup(&id, &b); err != nil {
				return 0, err
			}
			return b.Conns, nil
		})
}

func (v *wlcEstVariant) AddService(ip string, port uint16) error {
	pip, err := parseIPv4Cfg(ip)
	if err != nil {
		return err
	}
	key := lb3IpPort{Ip: pip, Port: htons(port)}
	val := true
	if err := v.objs.lb3Maps.Services.Update(&key, &val, ebpf.UpdateAny); err != nil {
		return fmt.Errorf("add service %s:%d: %w", ip, port, err)
	}
	return nil
}

func (v *wlcEstVariant) DeleteService(ip string, port uint16) error {
	pip, err := parseIPv4Cfg(ip)
	if err != nil {
		return err
	}
	key := lb3IpPort{Ip: pip, Port: htons(port)}
	if err := v.objs.lb3Maps.Services.Delete(&key); err != nil {
		return fmt.Errorf("delete service %s:%d: %w", ip, port, err)
	}
	return nil
}

// ── SYN variant (lb4 / lb_wlc_syn.c) ─────────────────────────────────────────

type wlcSynVariant struct {
	objs lb4Objects
}

func newWlcSynVariant() (*wlcSynVariant, error) {
	v := &wlcSynVariant{}
	if err := loadLb4Objects(&v.objs, nil); err != nil {
		return nil, fmt.Errorf("load BPF objects (wlc-syn): %w", err)
	}
	if err := pinMaps(map[string]*ebpf.Map{
		pinDir + "/backends":        v.objs.lb4Maps.Backends,
		pinDir + "/backend_count":   v.objs.lb4Maps.BackendCount,
		pinDir + "/services":        v.objs.lb4Maps.Services,
		pinDir + "/selection_array": v.objs.lb4Maps.SelectionArray,
	}, "wlc"); err != nil {
		v.objs.Close()
		return nil, err
	}
	return v, nil
}

func (v *wlcSynVariant) Program() *ebpf.Program { return v.objs.XdpLoadBalancer }
func (v *wlcSynVariant) Close()                 { v.objs.Close() }

func (v *wlcSynVariant) Init(cfgPath string) error {
	if err := initPorts(func(p uint16) error {
		return v.objs.lb4Maps.FreePorts.Update(nil, &p, ebpf.UpdateAny)
	}); err != nil {
		return fmt.Errorf("init ports: %w", err)
	}

	cfg, err := loadConfig(cfgPath)
	if err != nil {
		return err
	}

	if err := v.AddService(cfg.Service.VIP, cfg.Service.Port); err != nil {
		return fmt.Errorf("add service: %w", err)
	}

	for i, b := range cfg.Backends {
		ip, err := parseIPv4Cfg(b.IP)
		if err != nil {
			return fmt.Errorf("backend[%d] IP: %w", i, err)
		}
		id := nextBackendID
		nextBackendID++
		be := lb4Backend{
			Ip:     ip,
			Port:   htons(b.Port),
			Conns:  0,
			Weight: defaultWeight(b.Weight),
		}
		if err := v.objs.lb4Maps.Backends.Update(&id, &be, ebpf.UpdateAny); err != nil {
			return fmt.Errorf("update backends id=%d: %w", id, err)
		}
		pos := uint32(i)
		if err := v.objs.lb4Maps.SelectionArray.Update(pos, &id, ebpf.UpdateAny); err != nil {
			return fmt.Errorf("update selection_array[%d]: %w", i, err)
		}
	}

	cnt := uint32(len(cfg.Backends))
	if err := v.objs.lb4Maps.BackendCount.Update(uint32(0), &cnt, ebpf.UpdateAny); err != nil {
		return fmt.Errorf("update backend_count: %w", err)
	}
	return nil
}

func (v *wlcSynVariant) UpdateWeight(ip string, port, weight uint16) error {
	return wlcUpdateWeight(v.objs.lb4Maps.Backends, v.objs.lb4Maps.BackendCount,
		v.objs.lb4Maps.SelectionArray, ip, port, weight)
}

func (v *wlcSynVariant) AddBackend(ip string, port, weight uint16) error {
	return wlcAddBackend(v.objs.lb4Maps.Backends, v.objs.lb4Maps.BackendCount,
		v.objs.lb4Maps.SelectionArray, ip, port, weight,
		func(ip uint32, port, weight uint16) interface{} {
			return &lb4Backend{Ip: ip, Port: port, Conns: 0, Weight: weight}
		})
}

func (v *wlcSynVariant) DeleteBackend(ip string, port uint16) error {
	return wlcDeleteBackend(v.objs.lb4Maps.Backends, v.objs.lb4Maps.BackendCount,
		v.objs.lb4Maps.SelectionArray, ip, port,
		func(m *ebpf.Map, id uint32) (uint32, uint16, error) {
			var b lb4Backend
			if err := m.Lookup(&id, &b); err != nil {
				return 0, 0, err
			}
			return b.Ip, b.Port, nil
		},
		func(m *ebpf.Map, id uint32) (uint32, error) {
			var b lb4Backend
			if err := m.Lookup(&id, &b); err != nil {
				return 0, err
			}
			return b.Conns, nil
		})
}

func (v *wlcSynVariant) AddService(ip string, port uint16) error {
	pip, err := parseIPv4Cfg(ip)
	if err != nil {
		return err
	}
	key := lb4IpPort{Ip: pip, Port: htons(port)}
	val := true
	if err := v.objs.lb4Maps.Services.Update(&key, &val, ebpf.UpdateAny); err != nil {
		return fmt.Errorf("add service %s:%d: %w", ip, port, err)
	}
	return nil
}

func (v *wlcSynVariant) DeleteService(ip string, port uint16) error {
	pip, err := parseIPv4Cfg(ip)
	if err != nil {
		return err
	}
	key := lb4IpPort{Ip: pip, Port: htons(port)}
	if err := v.objs.lb4Maps.Services.Delete(&key); err != nil {
		return fmt.Errorf("delete service %s:%d: %w", ip, port, err)
	}
	return nil
}

// ── generic map helpers ───────────────────────────────────────────────────────

// lookupIPPortFn and lookupConnsFn receive a stable backend ID (hash map key).
type (
	lookupIPPortFn func(m *ebpf.Map, id uint32) (ip uint32, port uint16, err error)
	lookupConnsFn  func(m *ebpf.Map, id uint32) (conns uint32, err error)
	makeFn         func(ip uint32, port, weight uint16) interface{}
)

func wlcUpdateWeight(backends, countMap, selectionArray *ebpf.Map,
	ip string, port, weight uint16) error {

	pip, err := parseIPv4Cfg(ip)
	if err != nil {
		return err
	}
	var count uint32
	if err := countMap.Lookup(uint32(0), &count); err != nil {
		return fmt.Errorf("lookup count: %w", err)
	}
	type raw struct {
		Ip     uint32
		Port   uint16
		Weight uint16
		Conns  uint32
	}
	for i := uint32(0); i < count; i++ {
		var id uint32
		if err := selectionArray.Lookup(i, &id); err != nil {
			continue
		}
		var b raw
		if err := backends.Lookup(&id, &b); err != nil {
			continue
		}
		if b.Ip == pip && b.Port == htons(port) {
			b.Weight = weight
			if err := backends.Update(&id, &b, ebpf.UpdateExist); err != nil {
				return fmt.Errorf("update weight: %w", err)
			}
			return nil
		}
	}
	return fmt.Errorf("backend %s:%d not found", ip, port)
}

func wlcAddBackend(backends, countMap, selectionArray *ebpf.Map,
	ip string, port, weight uint16, make makeFn) error {

	pip, err := parseIPv4Cfg(ip)
	if err != nil {
		return err
	}
	if weight == 0 {
		weight = 1
	}
	var count uint32
	if err := countMap.Lookup(uint32(0), &count); err != nil {
		return fmt.Errorf("lookup count: %w", err)
	}
	// Duplicate check via selection_array.
	type raw struct {
		Ip     uint32
		Port   uint16
		Weight uint16
		Conns  uint32
	}
	for i := uint32(0); i < count; i++ {
		var id uint32
		if err := selectionArray.Lookup(i, &id); err != nil {
			continue
		}
		var b raw
		if err := backends.Lookup(&id, &b); err != nil {
			continue
		}
		if b.Ip == pip && b.Port == htons(port) {
			return fmt.Errorf("backend %s:%d already exists", ip, port)
		}
	}
	// Assign a new stable ID.
	id := nextBackendID
	nextBackendID++
	be := make(pip, htons(port), weight)
	if err := backends.Update(&id, be, ebpf.UpdateAny); err != nil {
		return fmt.Errorf("insert backend: %w", err)
	}
	// Append to selection_array at position count.
	if err := selectionArray.Update(count, &id, ebpf.UpdateAny); err != nil {
		return fmt.Errorf("update selection_array: %w", err)
	}
	count++
	if err := countMap.Update(uint32(0), &count, ebpf.UpdateExist); err != nil {
		return fmt.Errorf("update count: %w", err)
	}
	return nil
}

func wlcDeleteBackend(backends, countMap, selectionArray *ebpf.Map,
	ip string, port uint16,
	lookupIPPort lookupIPPortFn, lookupConns lookupConnsFn) error {

	pip, err := parseIPv4Cfg(ip)
	if err != nil {
		return err
	}
	var count uint32
	if err := countMap.Lookup(uint32(0), &count); err != nil {
		return fmt.Errorf("lookup count: %w", err)
	}
	for i := uint32(0); i < count; i++ {
		var id uint32
		if err := selectionArray.Lookup(i, &id); err != nil {
			continue
		}
		bip, bport, err := lookupIPPort(backends, id)
		if err != nil {
			continue
		}
		if bip != pip || bport != htons(port) {
			continue
		}
		conns, err := lookupConns(backends, id)
		if err != nil {
			return fmt.Errorf("lookup conns: %w", err)
		}
		if conns != 0 {
			return fmt.Errorf("backend %s:%d has %d active connections", ip, port, conns)
		}
		last := count - 1
		if i != last {
			var lastID uint32
			if err := selectionArray.Lookup(last, &lastID); err != nil {
				return fmt.Errorf("lookup last id: %w", err)
			}
			if err := selectionArray.Update(i, &lastID, ebpf.UpdateExist); err != nil {
				return fmt.Errorf("swap selection_array: %w", err)
			}
		}
		// Zero the vacated last slot — selection_array is an array map.
		zero := uint32(0)
		if err := selectionArray.Update(last, &zero, ebpf.UpdateExist); err != nil {
			return fmt.Errorf("zero selection_array last slot: %w", err)
		}
		// Real delete from hash map by stable ID.
		if err := backends.Delete(&id); err != nil {
			return fmt.Errorf("delete backend: %w", err)
		}
		count--
		if err := countMap.Update(uint32(0), &count, ebpf.UpdateExist); err != nil {
			return fmt.Errorf("update count: %w", err)
		}
		return nil
	}
	return fmt.Errorf("backend %s:%d not found", ip, port)
}